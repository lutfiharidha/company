@extends('layouts.navb')
@section('content')
	<div class="uk-card uk-card-default uk-box-shadow-large uk-grid-collapse uk-child-width-1-2@s uk-margin" uk-grid>
    <div class="uk-card-media-left uk-cover-container">
        <img src="https://getuikit.com/docs/images/light.jpg" alt="" uk-cover>
        <canvas width="600" height="400"></canvas>
    </div>
    <div>
        <div class="uk-card-body uk-flex uk-flex-column uk-text-large ">
            <h1 class="uk-text-bold uk-text-center">Media Left</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>
<button class="uk-button uk-button-secondary uk-width-1-1">View Work</button>
        </div>
    </div>
</div>
    <div class="uk-card uk-card-default uk-box-shadow-large uk-grid-collapse uk-child-width-1-2@s uk-margin" uk-grid>
    <div class="uk-flex-last@s uk-card-media-right uk-cover-container">
        <img src="https://getuikit.com/docs/images/light.jpg" alt="" uk-cover>
        <canvas width="600" height="400"></canvas>
    </div>
    <div>
        <div class="uk-card-body uk-flex uk-flex-column uk-text-large ">
            <h1 class="uk-text-bold uk-text-center">Media Left</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>
<button class="uk-button uk-button-secondary uk-width-1-1">View Work</button>
        </div>
    </div>
</div>
    <div class="uk-card uk-card-default uk-box-shadow-large uk-grid-collapse uk-child-width-1-2@s uk-margin" uk-grid>
    <div class="uk-card-media-left uk-cover-container">
        <img src="https://getuikit.com/docs/images/light.jpg" alt="" uk-cover>
        <canvas width="600" height="400"></canvas>
    </div>
    <div>
        <div class="uk-card-body uk-flex uk-flex-column uk-text-large ">
            <h1 class="uk-text-bold uk-text-center">Media Left</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>
<button class="uk-button uk-button-secondary uk-width-1-1">View Work</button>
        </div>
    </div>
</div>
 <div class="uk-card uk-card-default uk-box-shadow-large uk-grid-collapse uk-child-width-1-2@s uk-margin" uk-grid>
    <div class="uk-flex-last@s uk-card-media-right uk-cover-container">
        <img src="https://getuikit.com/docs/images/light.jpg" alt="" uk-cover>
        <canvas width="600" height="400"></canvas>
    </div>
    <div>
        <div class="uk-card-body uk-flex uk-flex-column uk-text-large ">
            <h1 class="uk-text-bold uk-text-center">Media Left</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>
<button class="uk-button uk-button-secondary uk-width-1-1">View Work</button>
        </div>
    </div>
</div>
@endsection
<?php $__env->startSection('content'); ?>
<div class="uk-container uk-container-medium uk-card uk-card-secondary" uk-scrollspy="cls: uk-animation-fade; repeat: true">
<form action="<?php echo e(route('update.slider', $slider)); ?>"  enctype="multipart/form-data" method="post">
   <fieldset class=" uk-margin-top uk-fieldset">
      <?php echo e(csrf_field()); ?>

      <?php echo e(method_field('PATCH')); ?>

      <legend class="uk-legend ">Slider Update</legend>
      Title
      <div class="uk-margin">
         <input class="uk-input" type="text" name="title" value="<?php echo e($slider->title); ?>">
      </div>
      Image
      <div class="uk-margin">
          <img width="150" height="150" src="<?php echo e(url($slider->img)); ?>">
         <div uk-form-custom>
            <input type="file" name="file">
            <button class="uk-button uk-button-default" type="button" tabindex="-1">Select</button>
         </div>
      </div>
      Alt
      <div class="uk-margin">
         <input class="uk-input" type="text" name="alt" value="<?php echo e($slider->alt); ?>">
      </div>
      Content
      <div class="uk-margin">
         <textarea class="uk-textarea ckeditor" id="ckedtor" name="content" rows="5"><?php echo e($slider->content); ?></textarea>
      </div>
      Status
      <div class="uk-margin">
         <div class="uk-form-controls">
            <select class="uk-select" id="form-stacked-select" name="status">
               <?php if($slider->status == "Publish"): ?>
               <option value="<?php echo e($slider->status); ?>"><?php echo e($slider->status); ?></option>
               <option value="Not Publish">Not Publish</option>
               <?php else: ?>
               <option value="<?php echo e($slider->status); ?>"><?php echo e($slider->status); ?></option>
               <option value="Publish">Publish</option>
               <?php endif; ?>
            </select>
         </div>
      </div>
   </fieldset>
   <div class="uk-margin">
      <input  class="uk-button uk-button-default" type="submit" placeholder="Post">
</form>
</div>
<?php if(session()->has('message')): ?>
<script>UIkit.notification({message: 'Slider Has Been Added', pos: 'bottom-center'})</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
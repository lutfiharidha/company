<!DOCTYPE html>
<html>
<head>
    <title><?php echo e(config('app.name')); ?></title>
          <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- UIkit CSS -->
<link rel="stylesheet" href="<?php echo e(url('css/uikit.min.css')); ?>" />
<link href="https://fonts.googleapis.com/css?family=Titillium+Web:300" rel="stylesheet">
<!-- UIkit JS -->
<script src="<?php echo e(url('js/uikit.min.js')); ?>"></script>
<script src="<?php echo e(url('js/uikit-icons.min.js')); ?>"></script>
      <script src="<?php echo e(asset('unisharp/laravel-ckeditor/ckeditor.js')); ?>"></script>
      <script src="<?php echo e(asset('unisharp/laravel-ckeditor/adapters/jquery.js')); ?>"></script>
</head>
<body>
    <nav class="uk-navbar-container" uk-navbar uk-sticky>
        <div class="uk-navbar-left uk-margin-medium-left">
                <a class="uk-navbar-item uk-logo" href="/">Company</a>
        </ul>
    </div>
<?php if(auth()->guard()->guest()): ?>
<?php else: ?>
    <div class="uk-navbar-right uk-navbar-item uk-margin-medium-right">
        <ul class="uk-navbar-nav">
            <li class="uk-active">
                <a class="uk-navbar-item" href="/home">Dashboard</a>
            </li>
            <li class="uk-active">
                <a href="<?php echo e(route('pages')); ?>">About</a>
            </li>
            <li class="uk-active">
                <a href="<?php echo e(route('slider')); ?>">Slider</a>
            </li>
            <li class="uk-active">
                <a href="#">News</a>
            </li>
            <li class="uk-active">
               <a class="uk-navbar-item" href="<?php echo e(route('logout')); ?>"
                              onclick="event.preventDefault();
                              document.getElementById('logout-form').submit();">
                           <?php echo e(__('Logout')); ?>

                           </a>
                           <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                              <?php echo csrf_field(); ?>
                           </form>
            </li>
        </ul>
    </div>
<?php endif; ?>      
</nav>
<?php echo $__env->yieldContent('content'); ?>
</body>
</html>
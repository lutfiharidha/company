<?php $__env->startSection('content'); ?>
<div class="uk-container uk-container-medium uk-padding">
    <h3 class="uk-heading uk-text-left">Visitor <span class="uk-label uk-label-primary"><?php echo e(DB::table('visitlogs')->count()); ?></span></h3>
<table class="uk-table uk-table-hover uk-table-divider">
    <thead>
        <tr>
            <th>No</th>
            <th>IP Address</th>
            <th>Country</th>
            <th>Region</th>
            <th>City</th>
            <th>User</th>
            <th>Device</th>
            <th>Browser</th>
            <th>Last Activity</th>
        </tr>
    </thead>
    <tbody>
            <?php $__currentLoopData = $visit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(++$key); ?></td>
            <td><?php echo e($v->ip); ?></td>
            <td><?php echo e($v->region_code); ?></td>
            <td><?php echo e($v->region_name); ?></td>
            <td><?php echo e($v->city); ?></td>
            <td><?php echo e($v->user_name); ?></td>
            <td><?php echo e($v->os); ?></td>
            <td><?php echo e($v->browser); ?></td>
            <td><?php echo e($v->last_visit); ?></td>
        </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="uk-container uk-container-medium uk-padding">
    <h3 class="uk-heading uk-text-left">Slider</h3>
    <div class="uk-heading uk-text-right">
        <a class="uk-button uk-button-text" href="<?php echo e(route('slider.create')); ?>">+ Add Slider</a>
    </div>
<table class="uk-table uk-table-hover uk-table-divider">
    <thead>
        <tr>
            <th>No</th>
            <th>Image</th>
            <th>Title</th>
            <th>Content</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e(++$key); ?></td>
           <td><img width="150" height="150" src="<?php echo e(asset($slider->img)); ?>"></td>
           <td><?php echo e($slider->title); ?></td>
           <td><?php echo str_limit($slider->content,200,' ...'); ?></td>
           <td><?php echo e($slider->status); ?></td>
           <td>
            <a class="uk-button uk-button-text uk-text-primary" href="<?php echo e(route('edit.slider',$slider)); ?>">Update</a><br>
            <form action="<?php echo e(route('slider.destroy',$slider)); ?>" method="post">
                  <?php echo e(csrf_field()); ?>

                  <?php echo e(method_field('DELETE')); ?>

            <button class="uk-button uk-button-text uk-text-danger">Delete</button>
               </form>
           </td>
        </tr>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
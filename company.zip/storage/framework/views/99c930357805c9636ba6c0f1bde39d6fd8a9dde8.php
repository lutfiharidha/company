<?php $__env->startSection('content'); ?>
<div class="uk-container uk-container-medium uk-card uk-card-secondary" uk-scrollspy="cls: uk-animation-fade; repeat: true">
<form action="<?php echo e(route('update.pages',$page)); ?>"  enctype="multipart/form-data" method="post">
   <fieldset class=" uk-margin-top uk-fieldset">
      <?php echo e(csrf_field()); ?>

      <?php echo e(method_field('PATCH')); ?>

      <legend class="uk-legend ">Posting</legend>
      <div class="uk-margin">
         Page Name
         <input class="uk-input" type="text" name="page" value="<?php echo e($page->page); ?>">
      </div>
      <div class="uk-margin">
         Image
         <img width="150" height="150" src="<?php echo e(url($page->img)); ?>">
         <div uk-form-custom>
            <input type="file" name="file">
            <button class="uk-button uk-button-default" type="button" tabindex="-1">Select</button>
         </div>
      </div>
      <div class="uk-margin">
         Content
         <textarea class="uk-textarea ckeditor" id="ckedtor" name="content" rows="5"><?php echo e($page->content); ?></textarea>
      </div>
      <div class="uk-margin">
         Status
         <div class="uk-form-controls">
            <select class="uk-select" id="form-stacked-select" name="status">
               <?php if($page->status == "Publish"): ?>
               <option value="<?php echo e($page->status); ?>"><?php echo e($page->status); ?></option>
               <option value="Not">Not Publish</option>
               <?php else: ?>
               <option value="<?php echo e($page->status); ?>"><?php echo e($page->status); ?></option>
               <option value="Publish">Publish</option>
               <?php endif; ?>
            </select>
         </div>
      </div>
   </fieldset>
   <div class="uk-margin">
      <input  class="uk-button uk-button-default" type="submit" value="Post">
</form>
</div>
<?php if(session()->has('message')): ?>
<script>UIkit.notification({message: 'Berhasil Di Update', pos: 'bottom-center'})</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use VisitLog;
use App\Page;
use App\Slider;

class UtamaController extends Controller
{
        public function index()
    {
    	VisitLog::save();
    	$about = Page::all()->where('page','=','about');
    	$sliders = Slider::all()->where('status','=','Publish');
        return view('welcome',compact('about','sliders'));
    }
}
